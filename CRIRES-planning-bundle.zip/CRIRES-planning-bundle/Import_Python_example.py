#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Feb 10 14:21:11 2020

@author: jonaszbinden
"""

import python_programming_example

python_programming_example.main()